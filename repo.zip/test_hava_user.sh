echo "hi,preinstall"
ROOT="/data/micro-services/"
echo $ROOT
id sloong
have_user=$?
echo $hava_user